package com.example.selectorclamp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ShapeSelectorActivity extends AppCompatActivity implements  AdapterView.OnItemSelectedListener {
    String[] colores = { "Blanco", "Negro", "Rojo", "Amarillo", "Verde", "Azul", "Marrón", "Naranja", "Lila", "Gris"};
    CardView linearLayoutCuadrados, linearLayoutTriangulos, linearLayoutRectangulos, linearLayoutCirculos;
    ImageView btCuadrado, btTriangulo, btRectangulo, btCirculo;
    Button btAceptar;
    boolean esRectangulo = false;
    boolean esTriangulo = false;
    boolean esCuadrado = false;
    boolean esCirculo = false;
    String color = null;
    String forma = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shape_selector);
        Spinner spin = (Spinner) findViewById(R.id.color_spinner);
        spin.setOnItemSelectedListener(this);
        setTitle("Seleccionar por color");

        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_item,colores);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(aa);

        linearLayoutCuadrados = (CardView) findViewById(R.id.card_cuadrado);
        linearLayoutRectangulos = (CardView) findViewById(R.id.card_rectangulo);
        linearLayoutTriangulos = (CardView) findViewById(R.id.card_triangulo);
        linearLayoutCirculos = (CardView) findViewById(R.id.card_circulo);
        btCuadrado = (ImageView) findViewById(R.id.imCuadrado);
        btCirculo = (ImageView) findViewById(R.id.imCirculo);
        btRectangulo = (ImageView) findViewById(R.id.imRectangulo);
        btTriangulo = (ImageView) findViewById(R.id.imTriangulo);
        btAceptar = (Button) findViewById(R.id.btAceptar);

        btCuadrado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(esCuadrado == true){
                    esCuadrado = false;
                    btCuadrado.setImageResource(R.drawable.cuadrado);
                }else{
                    btCuadrado.setImageResource(R.drawable.cuadradocompleto);
                    esCuadrado = true;
                    forma = "cuadrado";
                }
            }
        });
        btRectangulo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(esRectangulo == true){
                    esRectangulo = false;
                    btRectangulo.setImageResource(R.drawable.rectangulo);
                }else{
                    btRectangulo.setImageResource(R.drawable.rectangulocompleto);
                    esRectangulo = true;
                    forma = "rectangulo";
                }
            }
        });
        btCirculo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(esCirculo == true){
                    esCirculo = false;
                    btCirculo.setImageResource(R.drawable.circulo);
                }else{
                    btCirculo.setImageResource(R.drawable.circulocompleto);
                    esCirculo = true;
                    forma = "circulo";
                }
            }
        });
        btTriangulo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(esTriangulo == true){
                    esTriangulo = false;
                    btTriangulo.setImageResource(R.drawable.triangulo);
                }else{
                    btTriangulo.setImageResource(R.drawable.triangulocompleto);
                    esTriangulo = true;
                    forma = "triangulo";
                }
            }
        });

        btAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference colorRef = database.getReference("color");
                colorRef.setValue(color);
                DatabaseReference formaRef = database.getReference("forma");
                formaRef.setValue(forma);
                finish();
            }
        });

    }
    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
        //Toast.makeText(getApplicationContext(),colores[position] , Toast.LENGTH_LONG).show();
        color = colores[position];
    }
    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
    }

    @Override
    public final void onBackPressed() {
        finish();
    }
}