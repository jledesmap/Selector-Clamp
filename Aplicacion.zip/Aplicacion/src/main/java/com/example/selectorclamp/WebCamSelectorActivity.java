package com.example.selectorclamp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class WebCamSelectorActivity extends AppCompatActivity {

    ImageView mCircleImageView;
    int PICK_IMAGE_REQUEST = 111;
    Uri mImageUri;
    ProgressDialog pd;
    Button btAceptar;
    StorageTask mUploadTask;

    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference  mStorageRef = storage.getReferenceFromUrl("gs://selectorclamp.appspot.com/imagenes");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_cam_selector);
        setTitle("Seleción por imagen");

        btAceptar = (Button) findViewById(R.id.btAceptar);
        mCircleImageView = (ImageView) findViewById(R.id.image);

        mCircleImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImgChooser();
            }
        });

        btAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }


    protected void openImgChooser(){
        Intent i = new Intent();
        i.setType("image/*");
        i.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(i,PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null){
            mImageUri = data.getData();
            Picasso.get().load(mImageUri).into(mCircleImageView);
            if(mUploadTask != null && mUploadTask.isInProgress()) {
                Toast.makeText(WebCamSelectorActivity.this, "Upload in progress", Toast.LENGTH_SHORT).show();
            }else{
                uploadFile();
            }
        }
    }

    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }
    protected void uploadFile(){
        Log.d("PROVES", "uploadFile buida");
        if(mImageUri != null){
            final StorageReference fileReference = mStorageRef.child("imagen1." + getFileExtension(mImageUri));

            mUploadTask = fileReference.putFile(mImageUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Toast.makeText(WebCamSelectorActivity.this,"Subido correctamente", Toast.LENGTH_LONG).show();

                            FirebaseDatabase database = FirebaseDatabase.getInstance();
                            DatabaseReference colorRef = database.getReference("buscar");
                            colorRef.setValue("si");

                            // UploadImg upload = new UploadImg(taskSnapshot.getUploadSessionUri().toString()); //taskSnapshot.getMetadata().getReference().getDownloadUrl().toString()
                            fileReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    final String downloadUrl = uri.toString();
                                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                                    DatabaseReference urlref = database.getReference("image_url");
                                    urlref.setValue(downloadUrl);

                                }
                            });

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(WebCamSelectorActivity.this,"No se ha subido", Toast.LENGTH_LONG).show();
                        }
                    });
        }else{
            Toast.makeText(WebCamSelectorActivity.this,"Select a file", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public final void onBackPressed() {
        finish();
    }
}
