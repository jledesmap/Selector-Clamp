package com.example.selectorclamp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    LinearLayout linearLayoutColor, linearLayoutForma, linearLayoutImagen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linearLayoutColor = (LinearLayout) findViewById(R.id.card_color);
        linearLayoutForma = (LinearLayout) findViewById(R.id.card_forma);
        linearLayoutImagen = (LinearLayout) findViewById(R.id.card_foto);

        linearLayoutColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ColorSelectorActivity.class);
                startActivity(i);
            }
        });

        linearLayoutForma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ShapeSelectorActivity.class);
                startActivity(i);
            }
        });

        linearLayoutImagen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, WebCamSelectorActivity.class);
                startActivity(i);
            }
        });
    }
}
